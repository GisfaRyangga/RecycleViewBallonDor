package com.example.recycleview;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class BallonDorAdapter extends RecyclerView.Adapter<BallonDorAdapter.ViewHolder>{

    private final ArrayList<BallonDor> values;
    private final LayoutInflater inflater;

        public BallonDorAdapter(Context context, ArrayList<BallonDor> values) {
        this.values = values;
        this.inflater = LayoutInflater.from(context);
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.item_ballondor,parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        BallonDor ballonDor = values.get(position);
        holder.txtName.setText(ballonDor.nama);
        holder.txtRank.setText(ballonDor.peringkat);
        holder.txtClub.setText(ballonDor.klub);

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(holder.itemView.getContext(), BallonDorDetail.class);
                intent.putExtra("nama", ballonDor.nama);
                intent.putExtra("peringkat", ballonDor.peringkat);
                intent.putExtra("klub", ballonDor.klub);
                holder.itemView.getContext().startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return values.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        TextView txtName, txtRank, txtClub;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            txtName = itemView.findViewById(R.id.txt_nama);
            txtRank = itemView.findViewById(R.id.txt_peringkat);
            txtClub = itemView.findViewById(R.id.txt_klub);
        }
    }
}
