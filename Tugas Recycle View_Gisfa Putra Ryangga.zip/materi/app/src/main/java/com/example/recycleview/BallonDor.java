package com.example.recycleview;

public class BallonDor {
    String nama;
    String peringkat;
    String klub;

    public BallonDor(String nama, String peringkat, String klub) {
        this.nama = nama;
        this.peringkat = peringkat;
        this.klub = klub;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getPeringkat() {
        return peringkat;
    }

    public void setPeringkat(String peringkat) {
        this.peringkat = peringkat;
    }

    public String getKlub() {
        return klub;
    }

    public void setKlub(String desc) {
        this.klub = desc;
    }
}
