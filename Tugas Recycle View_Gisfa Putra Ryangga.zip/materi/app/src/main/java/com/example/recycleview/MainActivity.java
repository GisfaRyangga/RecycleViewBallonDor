package com.example.recycleview;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    private ArrayList<BallonDor> ballonDors = new ArrayList<>();
    private BallonDorAdapter ballonDorAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        addData();

        ballonDorAdapter = new BallonDorAdapter(this, ballonDors);
        recyclerView = findViewById(R.id.rv_ballondor);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(ballonDorAdapter);
    }

    private void addData() {
        ballonDors.add(new BallonDor("Karim Benzema", "Peringkat 1", "Real Madrid"));
        ballonDors.add(new BallonDor("Sadio Mane", "Peringkat 2", "FC Bayern Munchen"));
        ballonDors.add(new BallonDor("Kevin De Bruyne", "Peringkat 3", "Manchester City"));
        ballonDors.add(new BallonDor("Robert Lewandowski", "Peringkat 4", "FC Barcelona"));
        ballonDors.add(new BallonDor("Mohamed Salah", "Peringkat 5", "Liverpool"));
        ballonDors.add(new BallonDor("Kylian Mbappe", "Peringkat 6", "Paris Saint-Germain"));
        ballonDors.add(new BallonDor("Thibaut Courtois", "Peringkat ", "Real Madrid"));
        ballonDors.add(new BallonDor("Vinicius Junior", "Peringkat 8", "Real Madrid"));
        ballonDors.add(new BallonDor("Luka Modric", "Peringkat 9", "Real Madrid"));
        ballonDors.add(new BallonDor("Erling Haaland", "Peringkat 10", "Manchester City"));
    }
}