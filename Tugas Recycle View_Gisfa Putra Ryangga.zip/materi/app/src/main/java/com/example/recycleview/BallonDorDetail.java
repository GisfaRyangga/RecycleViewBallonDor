package com.example.recycleview;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class BallonDorDetail extends AppCompatActivity {
    TextView txtName, txtRank, txtClub;
    String name, rank, club;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_animal);

        txtName = findViewById(R.id.txt_nama);
        txtRank = findViewById(R.id.txt_peringkat);
        txtClub = findViewById(R.id.txt_klub);

        Intent intent = getIntent();

        name = intent.getStringExtra("nama");
        rank = intent.getStringExtra("peringkat");
        club = intent.getStringExtra("klub");

        txtName.setText(name);
        txtRank.setText(rank);
        txtClub.setText(club);
    }
}